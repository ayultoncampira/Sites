/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { BARBERSHOP_CONFIG } from "./data/barbershopConfig";
import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { SocialProofBanner } from "./components/SocialProofBanner";
import { AboutSection } from "./components/AboutSection";
import { ServicesSection } from "./components/ServicesSection";
import { EditorialGallery } from "./components/EditorialGallery";
import { LocationSection } from "./components/LocationSection";
import { InstagramSection } from "./components/InstagramSection";
import { FinalCta } from "./components/FinalCta";
import { Footer } from "./components/Footer";
import { BookingModal } from "./components/BookingModal";

export default function App() {
  const [isBookingOpen, setIsBookingOpen] = useState(false);

  const handleOpenBooking = () => {
    if (BARBERSHOP_CONFIG.BOOKING_URL && BARBERSHOP_CONFIG.BOOKING_URL.trim() !== "") {
      window.open(BARBERSHOP_CONFIG.BOOKING_URL, "_blank", "noopener,noreferrer");
    } else {
      setIsBookingOpen(true);
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-[#F3F3F3] flex flex-col selection:bg-[#FF5500] selection:text-black">
      {/* Top Navigation */}
      <Navbar onOpenBooking={handleOpenBooking} />

      {/* Main Content Sections */}
      <main className="flex-1">
        <Hero onOpenBooking={handleOpenBooking} />
        <SocialProofBanner />
        <AboutSection />
        <ServicesSection onOpenBooking={handleOpenBooking} />
        <EditorialGallery />
        <LocationSection onOpenBooking={handleOpenBooking} />
        <InstagramSection />
        <FinalCta onOpenBooking={handleOpenBooking} />
      </main>

      {/* Footer */}
      <Footer onOpenBooking={handleOpenBooking} />

      {/* Booking Preparation / Direct Contact Modal */}
      <BookingModal
        isOpen={isBookingOpen}
        onClose={() => setIsBookingOpen(false)}
      />
    </div>
  );
}
