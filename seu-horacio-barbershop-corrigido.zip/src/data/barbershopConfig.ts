/**
 * CONFIGURAÇÃO CENTRAL — SEU HORÁCIO BARBERSHOP
 * 
 * Atualizado com os dados oficiais extraídos das publicações e capturas reais da barbearia:
 * - Lista oficial completa de 7 serviços confirmados
 * - Contato celular / WhatsApp oficial: (53) 98145-1699
 * - Telefone fixo de atendimento: (53) 3312-4573
 * - Fotografias reais do espaço (incluindo o icônico ambiente com bicicleta na parede de tijolos)
 */

export interface ServiceItem {
  id: string;
  name: string;
  category?: string;
  description: string;
  priceNote: string;
  price?: number;
  durationMinutes?: number;
  barber?: string;
}

export interface WorkingHours {
  days: string;
  daysShort: string;
  morning: string;
  afternoon: string;
  sunday: string;
  note?: string;
}

export const BARBERSHOP_CONFIG = {
  // Identidade da Empresa
  brandName: "Seu Horácio Barbershop",
  shortName: "Seu Horácio",
  tagline: "Seu visual merece atenção de quem entende de estilo.",
  // Logo em arquivo: quando o cliente enviar (PNG/SVG com fundo transparente),
  // salve em public/images/logo.png e troque este valor para "/images/logo.png".
  // Enquanto for null, Navbar e Footer continuam usando o nome em texto (wordmark).
  logoUrl: null as string | null,
  city: "Bagé",
  state: "RS",
  
  // Localização (Endereço de referência oficial no centro de Bagé)
  address: {
    street: "Av. Pres. Vargas, 336",
    neighborhood: "Centro",
    city: "Bagé",
    state: "RS",
    full: "Av. Pres. Vargas, 336 — Centro, Bagé — RS",
    googleMapsSearchUrl: "https://maps.google.com/?q=Av.+Pres.+Vargas,+336+-+Centro,+Bagé+-+RS",
    googleMapsEmbedUrl: "https://maps.google.com/maps?q=Av.+Pres.+Vargas,+336,+Centro,+Bag%C3%A9+-+RS&t=&z=16&ie=UTF8&iwloc=&output=embed",
  },

  // Contatos Oficiais Confirmados
  contact: {
    whatsapp: "(53) 98145-1699",
    whatsappRaw: "5553981451699",
    whatsappUrl: "https://wa.me/5553981451699?text=Ol%C3%A1!%20Gostaria%20de%20agendar%20um%20hor%C3%A1rio%20no%20Seu%20Hor%C3%A1cio%20Barbershop.",
    phone: "(53) 98145-1699",
    phoneTel: "+5553981451699",
    phoneLandline: "(53) 3312-4573",
    instagramHandle: "@seuhoraciobarbershop",
    instagramUrl: "https://www.instagram.com/seuhoraciobarbershop/",
  },

  // Prova Social Verificada (Dados Públicos do Google)
  reputation: {
    rating: "4,9",
    ratingNumeric: 4.9,
    reviewCount: "316",
    source: "Google",
  },

  // Horários de Atendimento
  hours: {
    days: "Segunda a sábado",
    daysShort: "SEG — SÁB",
    morning: "09:00 — 11:30",
    afternoon: "14:00 — 19:30",
    sunday: "Fechado",
    editableNotice: "Horários sujeitos a confirmação com o estabelecimento.",
  } as WorkingHours,

  /**
   * LINK DE AGENDAMENTO (BOOKING_URL)
   * 
   * Pode ser vinculado ao WhatsApp oficial da barbearia (wa.me) ou a qualquer sistema
   * (AppBarber, Trinks, Booksy). Como encontramos o WhatsApp oficial (53) 98145-1699
   * na imagem de serviços, deixamos pronto para contato direto!
   */
  BOOKING_URL: "https://wa.me/5553981451699?text=Ol%C3%A1!%20Gostaria%20de%20agendar%20um%20hor%C3%A1rio%20no%20Seu%20Hor%C3%A1cio.",

  // Lista OFICIAL de Serviços (Extraída diretamente da imagem oficial do Seu Horácio)
  services: [
    {
      id: "corte",
      name: "Corte",
      category: "Cabelo",
      description: "Corte tradicional, fade ou moderno com tesoura e máquina, finalização personalizada e alinhamento de contornos.",
      priceNote: "Consulte o valor",
    },
    {
      id: "barba",
      name: "Barba",
      category: "Barba",
      description: "Desenho e alinhamento com toalha quente, navalhete e produtos específicos para hidratação da pele e dos fios.",
      priceNote: "Consulte o valor",
    },
    {
      id: "sobrancelha",
      name: "Sobrancelha",
      category: "Face",
      description: "Limpeza precisa e alinhamento das sobrancelhas na navalha para valorizar a harmonia facial.",
      priceNote: "Consulte o valor",
    },
    {
      id: "barboterapia",
      name: "Barboterapia",
      category: "Tratamento",
      description: "Experiência relaxante completa com vapor de ozônio, toalha aromática aquecida, esfoliação facial e massagem.",
      priceNote: "Consulte o valor",
    },
    {
      id: "hidratacao",
      name: "Hidratação",
      category: "Cuidado Capilar",
      description: "Tratamento profundo com produtos profissionais para restauração da vitalidade, maciez e brilho dos cabelos.",
      priceNote: "Consulte o valor",
    },
    {
      id: "luzes",
      name: "Luzes",
      category: "Coloração",
      description: "Técnica de iluminação e mechas capilares masculinas com acabamento natural ou platinado de alto padrão.",
      priceNote: "Consulte o valor",
    },
    {
      id: "relaxamento-capilar",
      name: "Relaxamento Capilar",
      category: "Texturização",
      description: "Alinhamento e redução de volume dos fios, proporcionando praticidade e caimento impecável no dia a dia.",
      priceNote: "Consulte o valor",
    },
  ] as ServiceItem[],

  // Fotografias ilustrativas (banco de imagens) — trocar pelas fotos reais da loja
  // quando o cliente enviar. Caminho "/images/..." aponta para a pasta public/images,
  // que é copiada como está no build de produção (por isso funciona no site publicado).
  assets: {
    heroPortrait: "/images/horacio_barber_tattoo_styling_1790447096238.jpg",
    interiorShop: "/images/horacio_shop_bicycle_interior_1790447066395.jpg",
    scissorsCraft: "/images/horacio_barber_scissors_craft_1790447086195.jpg",
    fadeCut: "/images/horacio_barber_fade_glasses_1790447075936.jpg",
    // Fotos extras disponíveis em public/images, ainda não usadas em nenhuma seção:
    // barber_craft_shave_1790446136582.jpg
    // barber_tools_station_1790446155923.jpg
    // barbershop_interior_chair_1790446146300.jpg
    // hero_barber_portrait_1790446125856.jpg
  },
};
