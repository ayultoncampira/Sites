import React from "react";
import { Star, ShieldCheck, MapPin, Clock } from "lucide-react";
import { BARBERSHOP_CONFIG } from "../data/barbershopConfig";

export const SocialProofBanner: React.FC = () => {
  return (
    <section className="bg-[#121212] border-y border-[#222222] py-10 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-6 items-center">
          {/* Item 1: Google Rating */}
          <div className="flex items-center gap-4 border-b md:border-b-0 md:border-r border-[#262626] pb-6 md:pb-0 md:pr-6">
            <div className="w-14 h-14 bg-[#1C1C1C] border border-[#2E2E2E] flex items-center justify-center shrink-0">
              <Star className="w-7 h-7 fill-[#FF5500] text-[#FF5500]" />
            </div>
            <div>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-display font-bold text-white tabular-nums tracking-tight">
                  {BARBERSHOP_CONFIG.reputation.rating}
                </span>
                <span className="text-xs uppercase tracking-wider text-neutral-400 font-medium">
                  / 5.0 estrelas
                </span>
              </div>
              <p className="text-xs text-neutral-400 mt-0.5">
                Avaliação oficial no <strong className="text-neutral-200 font-semibold">{BARBERSHOP_CONFIG.reputation.source}</strong>
              </p>
            </div>
          </div>

          {/* Item 2: Public Review Count */}
          <div className="flex items-center gap-4 border-b md:border-b-0 md:border-r border-[#262626] pb-6 md:pb-0 md:pr-6">
            <div className="w-14 h-14 bg-[#1C1C1C] border border-[#2E2E2E] flex items-center justify-center shrink-0">
              <ShieldCheck className="w-7 h-7 text-[#FF5500]" />
            </div>
            <div>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-display font-bold text-white tabular-nums tracking-tight">
                  {BARBERSHOP_CONFIG.reputation.reviewCount}
                </span>
                <span className="text-xs uppercase tracking-wider text-neutral-400 font-medium">
                  avaliações
                </span>
              </div>
              <p className="text-xs text-neutral-400 mt-0.5">
                Reconhecimento público de clientes
              </p>
            </div>
          </div>

          {/* Item 3: Local Presence in Bagé */}
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-[#1C1C1C] border border-[#2E2E2E] flex items-center justify-center shrink-0">
              <MapPin className="w-7 h-7 text-[#FF5500]" />
            </div>
            <div>
              <p className="text-base font-display font-semibold uppercase text-white tracking-wide">
                Centro de Bagé — RS
              </p>
              <div className="flex items-center gap-1.5 text-xs text-neutral-400 mt-0.5">
                <Clock className="w-3.5 h-3.5 text-neutral-500" />
                <span>{BARBERSHOP_CONFIG.hours.daysShort} · 09h às 19h30</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
