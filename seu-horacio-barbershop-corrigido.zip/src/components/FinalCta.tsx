import React from "react";
import { ArrowRight, Phone, MapPin, MessageSquare } from "lucide-react";
import { BARBERSHOP_CONFIG } from "../data/barbershopConfig";

interface FinalCtaProps {
  onOpenBooking: () => void;
}

export const FinalCta: React.FC<FinalCtaProps> = ({ onOpenBooking }) => {
  return (
    <section className="py-24 sm:py-36 bg-[#0E0E0E] border-t border-[#1C1C1C] relative overflow-hidden text-center">
      {/* Background ambient lighting */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_40%,rgba(255,85,0,0.06),transparent_70%)] pointer-events-none" />

      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <p className="text-xs uppercase tracking-[0.3em] text-[#FF5500] font-semibold mb-4">
          {BARBERSHOP_CONFIG.brandName} · {BARBERSHOP_CONFIG.city} / {BARBERSHOP_CONFIG.state}
        </p>

        <h2 className="text-4xl sm:text-6xl lg:text-7xl font-display font-bold uppercase tracking-tight text-white leading-[0.95] mb-8 text-balance">
          SEU PRÓXIMO HORÁRIO COMEÇA AQUI.
        </h2>

        <p className="text-base sm:text-lg text-neutral-300 max-w-xl mx-auto mb-10 leading-relaxed">
          {BARBERSHOP_CONFIG.tagline}
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
          <button
            onClick={onOpenBooking}
            className="w-full sm:w-auto bg-[#FF5500] hover:bg-[#E04B00] text-black font-bold text-sm tracking-wider uppercase px-10 py-5 flex items-center justify-center gap-3 transition-colors cursor-pointer group shadow-xl shadow-[#FF5500]/15"
          >
            <span>AGENDAR HORÁRIO</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>

          <a
            href={`https://wa.me/${BARBERSHOP_CONFIG.contact.whatsappRaw}`}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto border border-[#FF5500] hover:bg-[#FF5500]/10 text-[#FF5500] font-semibold text-xs tracking-widest uppercase px-8 py-5 flex items-center justify-center gap-2 transition-colors"
          >
            <MessageSquare className="w-4 h-4 text-[#FF5500]" />
            <span className="tabular-nums">WHATSAPP {BARBERSHOP_CONFIG.contact.whatsapp}</span>
          </a>
        </div>

        {/* Quick Micro Anchors */}
        <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-8 text-xs text-neutral-400">
          <div className="flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5 text-[#FF5500]" />
            <span>{BARBERSHOP_CONFIG.address.street} — Centro</span>
          </div>
          <span className="text-neutral-600 hidden sm:inline" aria-hidden="true">·</span>
          <div className="flex items-center gap-1.5">
            <Phone className="w-3.5 h-3.5 text-neutral-500" />
            <span className="tabular-nums">Fixo: {BARBERSHOP_CONFIG.contact.phoneLandline}</span>
          </div>
          <span className="text-neutral-600 hidden sm:inline" aria-hidden="true">·</span>
          <span>{BARBERSHOP_CONFIG.hours.daysShort} · 09h–11h30 | 14h–19h30</span>
        </div>
      </div>
    </section>
  );
};
