import React from "react";
import { ArrowUpRight, Bike, Sparkles } from "lucide-react";
import { BARBERSHOP_CONFIG } from "../data/barbershopConfig";

export const AboutSection: React.FC = () => {
  return (
    <section id="a-barbearia" className="py-20 sm:py-28 bg-[#0A0A0A] relative border-t border-[#1C1C1C]">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="space-y-6">
          <div className="flex items-center gap-2">
            <span className="w-6 h-[2px] bg-[#FF5500]" />
            <span className="text-xs uppercase tracking-[0.25em] text-[#FF5500] font-semibold">
              A Barbearia
            </span>
          </div>

          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-display font-bold uppercase tracking-tight text-white leading-[0.95] text-balance">
            UM ESPAÇO PARA CUIDAR DO VISUAL
          </h2>

          <div className="pt-1">
            <p className="text-xl sm:text-2xl font-display uppercase tracking-wide text-neutral-300">
              {BARBERSHOP_CONFIG.brandName}
            </p>
            <p className="text-xs uppercase tracking-[0.2em] text-[#FF5500] font-medium mt-1">
              {BARBERSHOP_CONFIG.city} — {BARBERSHOP_CONFIG.state}
            </p>
          </div>

          <p className="text-neutral-300 text-base sm:text-lg leading-relaxed max-w-3xl">
            Localizada na Avenida Presidente Vargas, a Seu Horácio Barbershop reúne técnica, atendimento personalizado e um ambiente pensado para o bem-estar e alinhamento do visual masculino.
          </p>

          <div className="pt-6 border-t border-[#222222] grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div className="bg-[#121212] border border-[#222222] p-6">
              <p className="text-xs uppercase tracking-wider text-[#FF5500] font-semibold mb-2">Localização</p>
              <p className="text-base font-medium text-white">{BARBERSHOP_CONFIG.address.street}</p>
              <p className="text-xs text-neutral-400 mt-1">{BARBERSHOP_CONFIG.address.neighborhood} — {BARBERSHOP_CONFIG.city}, {BARBERSHOP_CONFIG.state}</p>
              <p className="text-xs text-neutral-400 mt-2">{BARBERSHOP_CONFIG.hours.daysShort} · {BARBERSHOP_CONFIG.hours.morning} e {BARBERSHOP_CONFIG.hours.afternoon}</p>
            </div>

            <div className="bg-[#121212] border border-[#222222] p-6">
              <p className="text-xs uppercase tracking-wider text-[#FF5500] font-semibold mb-2">Atendimento Direto</p>
              <p className="text-base font-medium text-white tabular-nums">
                WhatsApp: <a href={`https://wa.me/${BARBERSHOP_CONFIG.contact.whatsappRaw}`} target="_blank" rel="noopener noreferrer" className="text-[#FF5500] hover:underline">{BARBERSHOP_CONFIG.contact.whatsapp}</a>
              </p>
              <p className="text-xs text-neutral-400 mt-1 tabular-nums">Fixo: {BARBERSHOP_CONFIG.contact.phoneLandline}</p>
              <a
                href={BARBERSHOP_CONFIG.contact.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-xs text-[#FF5500] hover:underline mt-3"
              >
                <span>Instagram {BARBERSHOP_CONFIG.contact.instagramHandle}</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
