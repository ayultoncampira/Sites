import React from "react";
import { Camera, CheckCircle2, Sparkles } from "lucide-react";
import { BARBERSHOP_CONFIG } from "../data/barbershopConfig";

export const EditorialGallery: React.FC = () => {
  return (
    <section className="py-24 sm:py-32 bg-[#0A0A0A] border-t border-[#1C1C1C] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="mb-14">
          <div className="flex items-center gap-2 mb-2">
            <span className="w-6 h-[2px] bg-[#FF5500]" />
            <span className="text-xs uppercase tracking-[0.25em] text-[#FF5500] font-semibold">
              Galeria do Estabelecimento
            </span>
          </div>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-display font-bold uppercase tracking-tight text-white leading-none">
              O ESPAÇO & OS TRABALHOS
            </h2>
            <p className="text-xs sm:text-sm text-neutral-300 max-w-md">
              Registros reais do cotidiano, ambiente e execução dos cortes e barbas no Seu Horácio Barbershop em Bagé.
            </p>
          </div>
        </div>

        {/* Asymmetrical Composition */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          
          {/* Main Large Focal Image: Fade Haircut / Technique (Span 7 cols) */}
          <div className="lg:col-span-7 flex flex-col justify-between group">
            <div className="relative aspect-[4/3] sm:aspect-[16/11] bg-[#141414] overflow-hidden border border-[#242424]">
              <img
                src={BARBERSHOP_CONFIG.assets.fadeCut}
                alt="Barbeiro executando corte degradê"
                className="w-full h-full object-cover object-top filter contrast-[1.1] group-hover:scale-103 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent" />
              
              <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between">
                <h3 className="text-xl sm:text-2xl font-display font-semibold uppercase text-white tracking-wide">
                  Corte & Fade Degradê
                </h3>
              </div>
            </div>
          </div>

          {/* Right Column: Stacked Photos (Span 5 cols) */}
          <div className="lg:col-span-5 flex flex-col gap-6 justify-between">
            
            {/* Top Right: Scissors & Comb Craft */}
            <div className="group">
              <div className="relative aspect-[16/10] sm:aspect-[4/3] bg-[#141414] overflow-hidden border border-[#242424]">
                <img
                  src={BARBERSHOP_CONFIG.assets.scissorsCraft}
                  alt="Trabalho de tesoura e pente"
                  className="w-full h-full object-cover filter contrast-[1.08] group-hover:scale-103 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/65 via-transparent to-transparent" />
                
                <div className="absolute bottom-3 left-3 right-3 flex items-end justify-between">
                  <h3 className="text-lg font-display font-semibold uppercase text-white tracking-wide">
                    Tesoura & Texturização
                  </h3>
                </div>
              </div>
            </div>

            {/* Bottom Right: Shop Interior */}
            <div className="group">
              <div className="relative aspect-[16/9] sm:aspect-[4/3] bg-[#141414] overflow-hidden border border-[#242424]">
                <img
                  src={BARBERSHOP_CONFIG.assets.interiorShop}
                  alt="Espaço interno da barbearia"
                  className="w-full h-full object-cover filter contrast-[1.08] group-hover:scale-103 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/65 via-transparent to-transparent" />
                
                <div className="absolute bottom-3 left-3 right-3 flex items-end justify-between">
                  <h3 className="text-lg font-display font-semibold uppercase text-white tracking-wide">
                    O Salão & Ambiente
                  </h3>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </section>
  );
};
