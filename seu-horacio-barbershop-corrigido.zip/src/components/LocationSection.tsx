import React from "react";
import { MapPin, Phone, Clock, Navigation, ExternalLink, Calendar, MessageSquare } from "lucide-react";
import { BARBERSHOP_CONFIG } from "../data/barbershopConfig";

interface LocationSectionProps {
  onOpenBooking: () => void;
}

export const LocationSection: React.FC<LocationSectionProps> = ({ onOpenBooking }) => {
  return (
    <section id="localizacao" className="py-24 sm:py-32 bg-[#0E0E0E] border-t border-[#1C1C1C] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="mb-14">
          <div className="flex items-center gap-2 mb-2">
            <span className="w-6 h-[2px] bg-[#FF5500]" />
            <span className="text-xs uppercase tracking-[0.25em] text-[#FF5500] font-semibold">
              Localização & Contatos
            </span>
          </div>
          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-display font-bold uppercase tracking-tight text-white leading-none">
            ENCONTRE O SEU HORÁCIO
          </h2>
          <p className="text-sm text-neutral-300 mt-3 max-w-xl">
            Localização central e de fácil acesso na principal avenida de Bagé.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
          
          {/* Details Card (Span 5 cols) */}
          <div className="lg:col-span-5 bg-[#141414] border border-[#262626] p-6 sm:p-8 space-y-7">
            
            {/* Address */}
            <div className="space-y-1.5">
              <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-[#FF5500] font-semibold">
                <MapPin className="w-4 h-4 text-[#FF5500]" />
                <span>Endereço</span>
              </div>
              <p className="text-2xl font-display font-bold uppercase text-white tracking-wide">
                {BARBERSHOP_CONFIG.address.street}
              </p>
              <p className="text-sm text-neutral-300">
                {BARBERSHOP_CONFIG.address.neighborhood} — {BARBERSHOP_CONFIG.address.city}, {BARBERSHOP_CONFIG.address.state}
              </p>
            </div>

            {/* Official Phones: WhatsApp & Landline */}
            <div className="space-y-3 border-t border-[#222222] pt-6">
              <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-[#FF5500] font-semibold">
                <Phone className="w-4 h-4 text-[#FF5500]" />
                <span>Atendimento & Agendamento</span>
              </div>

              {/* WhatsApp Mobile */}
              <div className="flex items-center justify-between gap-4 p-3 bg-[#181818] border border-[#2A2A2A]">
                <div>
                  <span className="text-[11px] uppercase tracking-wider text-neutral-400 block font-medium">
                    WhatsApp & Celular
                  </span>
                  <span className="text-xl font-display font-bold text-white tabular-nums">
                    {BARBERSHOP_CONFIG.contact.whatsapp}
                  </span>
                </div>
                <a
                  href={`https://wa.me/${BARBERSHOP_CONFIG.contact.whatsappRaw}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-[#FF5500] hover:bg-[#E04B00] text-black font-semibold text-xs tracking-wider uppercase px-3.5 py-2 transition-colors flex items-center gap-1.5"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>Chamar</span>
                </a>
              </div>

              {/* Fixed Landline */}
              <div className="flex items-center justify-between text-xs text-neutral-400 px-1">
                <span>Telefone fixo:</span>
                <span className="text-neutral-200 font-semibold tabular-nums">{BARBERSHOP_CONFIG.contact.phoneLandline}</span>
              </div>
            </div>

            {/* Working Hours */}
            <div className="space-y-3 border-t border-[#222222] pt-6">
              <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-[#FF5500] font-semibold">
                <Clock className="w-4 h-4 text-[#FF5500]" />
                <span>Horários de Atendimento</span>
              </div>
              
              <div className="space-y-2 text-sm">
                <div className="flex items-start justify-between gap-4">
                  <span className="text-neutral-400 font-medium">Segunda a Sábado</span>
                  <div className="text-right text-white font-medium tabular-nums">
                    <div>{BARBERSHOP_CONFIG.hours.morning}</div>
                    <div>{BARBERSHOP_CONFIG.hours.afternoon}</div>
                  </div>
                </div>

                <div className="flex items-center justify-between gap-4 pt-1 border-t border-[#1F1F1F]">
                  <span className="text-neutral-500">Domingo</span>
                  <span className="text-neutral-400 font-medium">{BARBERSHOP_CONFIG.hours.sunday}</span>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="border-t border-[#222222] pt-6 flex flex-col sm:flex-row gap-3">
              <a
                href={BARBERSHOP_CONFIG.address.googleMapsSearchUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 bg-white hover:bg-neutral-200 text-black font-bold text-xs tracking-wider uppercase py-3.5 px-4 flex items-center justify-center gap-2 transition-colors"
              >
                <Navigation className="w-3.5 h-3.5 text-[#FF5500]" />
                <span>COMO CHEGAR</span>
              </a>

              <button
                onClick={onOpenBooking}
                className="flex-1 bg-[#FF5500] hover:bg-[#E04B00] text-black font-bold text-xs tracking-wider uppercase py-3.5 px-4 flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>AGENDAR</span>
              </button>
            </div>

          </div>

          {/* Map Embed (Span 7 cols) */}
          <div className="lg:col-span-7 flex flex-col h-full min-h-[420px] bg-[#141414] border border-[#262626] overflow-hidden">
            <div className="relative w-full h-[380px] lg:h-[480px]">
              <iframe
                title="Mapa de Localização - Seu Horácio Barbershop"
                src={BARBERSHOP_CONFIG.address.googleMapsEmbedUrl}
                className="w-full h-full border-0 filter invert-[0.88] hue-rotate-[180deg] contrast-[1.1] grayscale-[0.3]"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
            
            {/* Map Footer Bar */}
            <div className="bg-[#181818] p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-t border-[#262626] text-xs">
              <span className="text-neutral-300">
                {BARBERSHOP_CONFIG.address.full}
              </span>
              <a
                href={BARBERSHOP_CONFIG.address.googleMapsSearchUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#FF5500] hover:underline font-semibold flex items-center gap-1 shrink-0"
              >
                <span>Abrir no Google Maps</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
