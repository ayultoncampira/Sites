import React, { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";
import { BARBERSHOP_CONFIG } from "../data/barbershopConfig";

interface NavbarProps {
  onOpenBooking: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenBooking }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 24);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { label: "INÍCIO", href: "#inicio" },
    { label: "A BARBEARIA", href: "#a-barbearia" },
    { label: "SERVIÇOS", href: "#servicos" },
    { label: "LOCALIZAÇÃO", href: "#localizacao" },
  ];

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          isScrolled
            ? "bg-[#0A0A0A]/95 backdrop-blur-md border-b border-[#222222] py-3.5"
            : "bg-gradient-to-b from-black/90 to-transparent py-5"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          {/* Zone 1: Logo (imagem) quando disponível — senão, wordmark em texto */}
          <a
            href="#inicio"
            className="flex items-center text-xl sm:text-2xl font-display font-bold tracking-wider text-white hover:text-[#FF5500] transition-colors whitespace-nowrap"
          >
            {BARBERSHOP_CONFIG.logoUrl ? (
              <img
                src={BARBERSHOP_CONFIG.logoUrl}
                alt={BARBERSHOP_CONFIG.brandName}
                className="h-8 sm:h-9 w-auto object-contain"
              />
            ) : (
              BARBERSHOP_CONFIG.shortName.toUpperCase()
            )}
          </a>

          {/* Zone 2: 4 clean text navigation links */}
          <nav className="hidden md:flex items-center gap-8 text-xs font-semibold tracking-widest text-neutral-300 uppercase">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="hover:text-[#FF5500] transition-colors py-1 relative group"
              >
                {link.label}
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#FF5500] transition-all duration-200 group-hover:w-full" />
              </a>
            ))}
          </nav>

          {/* Zone 3: 1 primary action */}
          <div className="flex items-center gap-3">
            <button
              onClick={onOpenBooking}
              className="bg-[#FF5500] hover:bg-[#E04B00] text-black font-semibold text-xs tracking-wider uppercase px-4 sm:px-5 py-2.5 transition-colors whitespace-nowrap cursor-pointer"
            >
              AGENDAR HORÁRIO
            </button>

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-neutral-300 hover:text-white transition-colors cursor-pointer"
              aria-label="Abrir menu de navegação"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-30 bg-[#0A0A0A] pt-24 px-6 pb-8 flex flex-col justify-between md:hidden animate-in fade-in duration-200">
          <div className="flex flex-col space-y-6">
            <p className="text-xs uppercase tracking-widest text-[#FF5500] font-semibold">
              Navegação
            </p>
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="text-2xl font-display font-semibold tracking-wide text-white hover:text-[#FF5500] transition-colors"
              >
                {link.label}
              </a>
            ))}
          </div>

          <div className="border-t border-[#222222] pt-6 space-y-4">
            <div className="text-xs text-neutral-400 space-y-1">
              <p className="text-white font-medium">{BARBERSHOP_CONFIG.address.street}</p>
              <p>{BARBERSHOP_CONFIG.address.neighborhood} — {BARBERSHOP_CONFIG.address.city}, {BARBERSHOP_CONFIG.address.state}</p>
              <p className="text-neutral-300 tabular-nums pt-1">{BARBERSHOP_CONFIG.contact.phone}</p>
            </div>

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenBooking();
              }}
              className="w-full bg-[#FF5500] hover:bg-[#E04B00] text-black font-semibold text-sm tracking-wider uppercase py-3.5 transition-colors cursor-pointer"
            >
              AGENDAR HORÁRIO
            </button>
          </div>
        </div>
      )}
    </>
  );
};
