import React, { useState } from "react";
import { Phone, MapPin, Clock, ExternalLink, X, MessageSquare, CheckCircle2 } from "lucide-react";
import { BARBERSHOP_CONFIG } from "../data/barbershopConfig";

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BookingModal: React.FC<BookingModalProps> = ({ isOpen, onClose }) => {
  const [testUrl, setTestUrl] = useState("");
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleOpenTestUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!testUrl.trim()) return;
    const url = testUrl.startsWith("http") ? testUrl : `https://${testUrl}`;
    window.open(url, "_blank", "noopener,noreferrer");
  };

  const handleCopyPhone = () => {
    navigator.clipboard.writeText(BARBERSHOP_CONFIG.contact.whatsapp);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="booking-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm transition-opacity"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-lg bg-[#121212] border border-[#262626] rounded-none p-6 md:p-8 text-left shadow-2xl transition-all"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-neutral-400 hover:text-white p-2 transition-colors cursor-pointer"
          aria-label="Fechar janela"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Brand Kicker */}
        <p className="text-xs uppercase tracking-[0.2em] text-[#FF5500] font-semibold mb-2">
          {BARBERSHOP_CONFIG.brandName} · Bagé, RS
        </p>

        <h3 id="booking-modal-title" className="text-2xl md:text-3xl font-display uppercase tracking-wide text-white mb-2">
          Agendar Horário
        </h3>

        <p className="text-sm text-neutral-300 leading-relaxed mb-6">
          Agende seu horário diretamente com a equipe do <span className="text-white font-medium">{BARBERSHOP_CONFIG.shortName}</span> via WhatsApp ou telefone.
        </p>

        {/* WhatsApp Direct Action (Priority) */}
        <div className="bg-[#181818] border border-[#2A2A2A] p-4 mb-4">
          <div className="flex items-center justify-between gap-3 mb-2">
            <div className="flex items-center gap-2 text-white font-medium text-sm">
              <MessageSquare className="w-4 h-4 text-[#FF5500]" />
              <span>WhatsApp Oficial</span>
            </div>
            <button
              onClick={handleCopyPhone}
              className="text-xs text-neutral-400 hover:text-white transition-colors cursor-pointer"
            >
              {copied ? "Copiado!" : "Copiar"}
            </button>
          </div>
          <div className="flex items-center justify-between gap-4 mt-1">
            <span className="text-xl md:text-2xl font-display font-semibold text-white tracking-wider tabular-nums">
              {BARBERSHOP_CONFIG.contact.whatsapp}
            </span>
            <a
              href={`https://wa.me/${BARBERSHOP_CONFIG.contact.whatsappRaw}?text=Ol%C3%A1!%20Gostaria%20de%20agendar%20um%20hor%C3%A1rio%20no%20Seu%20Hor%C3%A1cio%20Barbershop.`}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-[#FF5500] hover:bg-[#E04B00] text-black font-semibold text-xs tracking-wider uppercase px-4 py-2.5 transition-colors whitespace-nowrap"
            >
              Chamar no Whats
            </a>
          </div>
        </div>

        {/* Fixed Line Secondary */}
        <div className="flex items-center justify-between p-3 bg-[#151515] border border-[#222222] mb-5 text-xs text-neutral-300">
          <div className="flex items-center gap-2">
            <Phone className="w-3.5 h-3.5 text-neutral-400" />
            <span>Telefone Fixo: <strong className="text-white tabular-nums">{BARBERSHOP_CONFIG.contact.phoneLandline}</strong></span>
          </div>
          <a
            href={`tel:${BARBERSHOP_CONFIG.contact.phoneLandline.replace(/\D/g, '')}`}
            className="text-[#FF5500] hover:underline font-semibold"
          >
            Ligar Fixo
          </a>
        </div>

        {/* Info Grid */}
        <div className="space-y-3 text-xs text-neutral-300 border-t border-[#262626] pt-4 mb-5">
          <div className="flex items-start gap-2.5">
            <MapPin className="w-4 h-4 text-[#FF5500] shrink-0 mt-0.5" />
            <div>
              <span className="text-white font-medium">Endereço: </span>
              <span>{BARBERSHOP_CONFIG.address.full}</span>
            </div>
          </div>
          <div className="flex items-start gap-2.5">
            <Clock className="w-4 h-4 text-[#FF5500] shrink-0 mt-0.5" />
            <div>
              <span className="text-white font-medium">Horários: </span>
              <span>{BARBERSHOP_CONFIG.hours.daysShort} · {BARBERSHOP_CONFIG.hours.morning} e {BARBERSHOP_CONFIG.hours.afternoon} (Domingo: {BARBERSHOP_CONFIG.hours.sunday})</span>
            </div>
          </div>
        </div>

        {/* Commercial Preview Note */}
        <div className="bg-[#151515] border-l-2 border-[#FF5500] p-3.5 text-xs text-neutral-400">
          <div className="flex items-center gap-1.5 text-neutral-200 font-semibold mb-1">
            <CheckCircle2 className="w-3.5 h-3.5 text-[#FF5500]" />
            <span>Link de Agendamento Personalizado</span>
          </div>
          <p className="leading-normal mb-3">
            O botão <strong>AGENDAR HORÁRIO</strong> pode ser direcionado para o WhatsApp ou conectado ao AppBarber, Trinks, Booksy ou site próprio.
          </p>

          <form onSubmit={handleOpenTestUrl} className="flex gap-2">
            <input
              type="text"
              placeholder="Inserir URL para testar redirecionamento..."
              value={testUrl}
              onChange={(e) => setTestUrl(e.target.value)}
              className="flex-1 bg-[#0A0A0A] border border-[#2E2E2E] px-3 py-1.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-[#FF5500]"
            />
            <button
              type="submit"
              disabled={!testUrl.trim()}
              className="bg-neutral-800 hover:bg-neutral-700 disabled:opacity-40 text-white px-3 py-1.5 text-xs font-medium flex items-center gap-1 transition-colors cursor-pointer disabled:cursor-not-allowed"
            >
              <span>Testar</span>
              <ExternalLink className="w-3 h-3" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
