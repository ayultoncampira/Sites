import React from "react";
import { ArrowUpRight } from "lucide-react";
import { BARBERSHOP_CONFIG } from "../data/barbershopConfig";

export const InstagramSection: React.FC = () => {
  return (
    <section className="py-20 bg-[#0A0A0A] border-t border-[#1C1C1C]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#121212] border border-[#242424] p-8 sm:p-12 flex flex-col md:flex-row items-start md:items-center justify-between gap-8">
          
          <div className="space-y-3 max-w-xl">
            <div className="flex items-center gap-2">
              <span className="w-5 h-[2px] bg-[#FF5500]" />
              <span className="text-xs uppercase tracking-[0.25em] text-[#FF5500] font-semibold">
                Canal Oficial
              </span>
            </div>

            <h3 className="text-3xl sm:text-4xl font-display font-bold uppercase tracking-tight text-white">
              {BARBERSHOP_CONFIG.contact.instagramHandle}
            </h3>

            <p className="text-sm text-neutral-400 leading-relaxed">
              Acompanhe novidades, trabalhos recentes e o cotidiano da barbearia diretamente no perfil oficial do Instagram.
            </p>
          </div>

          <div className="shrink-0">
            <a
              href={BARBERSHOP_CONFIG.contact.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-3 bg-white hover:bg-neutral-200 text-black font-bold text-xs tracking-wider uppercase px-7 py-4 transition-colors group"
            >
              <span>VER INSTAGRAM</span>
              <ArrowUpRight className="w-4 h-4 text-[#FF5500] group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </a>
          </div>

        </div>
      </div>
    </section>
  );
};
