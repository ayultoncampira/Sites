import React from "react";
import { ArrowRight, Scissors, Check, Sparkles } from "lucide-react";
import { BARBERSHOP_CONFIG } from "../data/barbershopConfig";

interface ServicesSectionProps {
  onOpenBooking: () => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onOpenBooking }) => {
  return (
    <section id="servicos" className="py-24 sm:py-32 bg-[#0E0E0E] border-t border-[#1F1F1F] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 pb-6 border-b border-[#242424] gap-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="w-5 h-[2px] bg-[#FF5500]" />
              <span className="text-xs uppercase tracking-[0.25em] text-[#FF5500] font-semibold">
                Menu Oficial de Atendimento
              </span>
            </div>
            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-display font-bold uppercase tracking-tight text-white leading-none">
              NOSSOS SERVIÇOS
            </h2>
            <p className="text-base text-neutral-300 font-medium mt-3">
              Cuidado, precisão e estilo para você.
            </p>
          </div>

          <div className="text-left md:text-right">
            <p className="text-xs text-neutral-400 max-w-sm mb-3">
              Todos os serviços realizados com produtos de alta performance e técnicas especializadas.
            </p>
            <button
              onClick={onOpenBooking}
              className="inline-flex items-center gap-2 bg-[#FF5500] hover:bg-[#E04B00] text-black font-bold text-xs tracking-wider uppercase px-5 py-3 transition-colors cursor-pointer"
            >
              <span>AGENDAR HORÁRIO</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Official Services List */}
        <div className="divide-y divide-[#222222] border-y border-[#222222]">
          {BARBERSHOP_CONFIG.services.map((service, index) => (
            <div
              key={service.id}
              className="py-6 sm:py-8 grid grid-cols-1 md:grid-cols-12 gap-4 md:gap-8 items-start group hover:bg-[#141414]/70 transition-colors px-2 sm:px-4"
            >
              {/* Index Column */}
              <div className="md:col-span-1 flex items-center md:items-start text-xs font-mono text-[#FF5500] font-semibold tabular-nums">
                0{index + 1}.
              </div>

              {/* Service Title & Category */}
              <div className="md:col-span-4">
                <div className="flex items-center gap-2">
                  <h3 className="text-2xl sm:text-3xl font-display uppercase tracking-wide text-white group-hover:text-[#FF5500] transition-colors">
                    {service.name}
                  </h3>
                </div>
                {service.category && (
                  <p className="text-xs uppercase tracking-widest text-[#FF5500]/90 font-medium mt-1">
                    {service.category}
                  </p>
                )}
              </div>

              {/* Description */}
              <div className="md:col-span-5">
                <p className="text-sm text-neutral-400 leading-relaxed">
                  {service.description}
                </p>
              </div>

              {/* Price Note & Action */}
              <div className="md:col-span-2 md:text-right flex md:flex-col justify-between items-center md:items-end gap-2 pt-2 md:pt-0">
                <span className="text-xs uppercase tracking-wider text-neutral-400 font-medium">
                  {service.priceNote}
                </span>
                <button
                  onClick={onOpenBooking}
                  className="text-xs text-[#FF5500] hover:text-[#E04B00] flex items-center gap-1 font-semibold uppercase tracking-wider cursor-pointer transition-colors"
                >
                  <span className="text-[#FF5500]">Agendar</span>
                  <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform text-[#FF5500]" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Quick Highlights of Services */}
        <div className="mt-8 p-5 bg-[#121212] border border-[#222222] flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs text-neutral-400">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-[#1C1C1C] border border-[#2B2B2B] flex items-center justify-center shrink-0">
              <Scissors className="w-4 h-4 text-[#FF5500]" />
            </div>
            <div>
              <p className="text-white font-medium">Cardápio de Serviços</p>
              <p className="text-[11px] text-neutral-400">Corte, Barba, Sobrancelha, Barboterapia, Hidratação, Luzes e Relaxamento Capilar.</p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-neutral-400">Atendimento com hora marcada:</span>
            <a
              href={`https://wa.me/${BARBERSHOP_CONFIG.contact.whatsappRaw}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#FF5500] font-semibold hover:underline"
            >
              {BARBERSHOP_CONFIG.contact.whatsapp}
            </a>
          </div>
        </div>

      </div>
    </section>
  );
};
