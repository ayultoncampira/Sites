import React from "react";
import { ArrowUpRight } from "lucide-react";
import { BARBERSHOP_CONFIG } from "../data/barbershopConfig";

interface FooterProps {
  onOpenBooking: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenBooking }) => {
  return (
    <footer className="bg-[#070707] border-t border-[#1C1C1C] py-16 text-neutral-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-[#1A1A1A]">
          
          {/* Brand Info (Span 5 cols) */}
          <div className="md:col-span-5 space-y-4">
            <h4 className="text-xl sm:text-2xl font-display font-bold uppercase tracking-wider text-white">
              {BARBERSHOP_CONFIG.brandName}
            </h4>
            <p className="text-neutral-400 text-sm max-w-sm leading-relaxed">
              {BARBERSHOP_CONFIG.tagline} Barbearia masculina no centro de Bagé, RS.
            </p>
            <div className="text-xs space-y-1 pt-1">
              <p className="text-[#FF5500] font-medium">{BARBERSHOP_CONFIG.address.street} — {BARBERSHOP_CONFIG.address.neighborhood}</p>
              <p className="text-neutral-400">{BARBERSHOP_CONFIG.address.city} — {BARBERSHOP_CONFIG.address.state}</p>
              <p className="text-[#FF5500] font-semibold tabular-nums pt-1">WhatsApp: {BARBERSHOP_CONFIG.contact.whatsapp} · Fixo: {BARBERSHOP_CONFIG.contact.phoneLandline}</p>
            </div>
          </div>

          {/* Quick Links (Span 3 cols) */}
          <div className="md:col-span-3 space-y-3">
            <p className="text-xs uppercase tracking-widest text-[#FF5500] font-semibold">
              Navegação
            </p>
            <ul className="space-y-2.5 text-xs text-neutral-300">
              <li>
                <a href="#inicio" className="hover:text-white transition-colors">Início</a>
              </li>
              <li>
                <a href="#a-barbearia" className="hover:text-white transition-colors">A Barbearia</a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-white transition-colors">Nossos Serviços</a>
              </li>
              <li>
                <a href="#localizacao" className="hover:text-white transition-colors">Localização & Contatos</a>
              </li>
            </ul>
          </div>

          {/* Direct Actions & Social (Span 4 cols) */}
          <div className="md:col-span-4 space-y-3">
            <p className="text-xs uppercase tracking-widest text-[#FF5500] font-semibold">
              Atendimento & Redes
            </p>
            <ul className="space-y-2.5 text-xs text-neutral-300">
              <li>
                <button
                  onClick={onOpenBooking}
                  className="hover:text-[#FF5500] text-left transition-colors cursor-pointer"
                >
                  Agendamento de Horário
                </button>
              </li>
              <li>
                <a
                  href={`https://wa.me/${BARBERSHOP_CONFIG.contact.whatsappRaw}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-[#FF5500] flex items-center gap-1 transition-colors text-white font-medium"
                >
                  <span>WhatsApp {BARBERSHOP_CONFIG.contact.whatsapp}</span>
                  <ArrowUpRight className="w-3 h-3 text-[#FF5500]" />
                </a>
              </li>
              <li>
                <a
                  href={BARBERSHOP_CONFIG.address.googleMapsSearchUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white flex items-center gap-1 transition-colors"
                >
                  <span>Localização no Google Maps</span>
                  <ArrowUpRight className="w-3 h-3 text-neutral-500" />
                </a>
              </li>
              <li>
                <a
                  href={BARBERSHOP_CONFIG.contact.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-[#FF5500] flex items-center gap-1 transition-colors text-white font-medium"
                >
                  <span>Instagram {BARBERSHOP_CONFIG.contact.instagramHandle}</span>
                  <ArrowUpRight className="w-3 h-3 text-[#FF5500]" />
                </a>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-[11px] text-neutral-400">
          <p>
            © {new Date().getFullYear()} {BARBERSHOP_CONFIG.brandName}. Todos os direitos reservados.
          </p>
          <p className="text-neutral-400">
            Av. Pres. Vargas, 336 — Centro, Bagé — RS
          </p>
        </div>

      </div>
    </footer>
  );
};
