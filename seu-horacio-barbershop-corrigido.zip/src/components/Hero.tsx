import React from "react";
import { Star, MapPin, ArrowRight, Phone } from "lucide-react";
import { BARBERSHOP_CONFIG } from "../data/barbershopConfig";

interface HeroProps {
  onOpenBooking: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenBooking }) => {
  return (
    <section id="inicio" className="relative min-h-[92vh] flex items-center pt-24 pb-16 overflow-hidden bg-[#0A0A0A]">
      {/* Background Hero Image with Dark Scrim */}
      <div className="absolute inset-0 z-0">
        <img
          src={BARBERSHOP_CONFIG.assets.heroPortrait}
          alt="Barbeiro da Seu Horácio Barbershop realizando atendimento"
          className="w-full h-full object-cover object-top filter brightness-[0.38] contrast-[1.15]"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0A0A0A] via-[#0A0A0A]/85 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A] via-transparent to-black/70" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="max-w-3xl">
          {/* Slogan Kicker */}
          <div className="inline-flex items-center gap-2 mb-4 text-xs tracking-[0.25em] uppercase text-[#FF5500] font-semibold">
            <span className="w-2 h-2 bg-[#FF5500] inline-block" />
            <span>Bagé — Rio Grande do Sul</span>
          </div>

          {/* Main Typography */}
          <h1 className="text-5xl sm:text-7xl lg:text-8xl font-display font-bold uppercase tracking-tight text-white leading-[0.92] mb-6">
            <span className="block text-white">SEU HORÁCIO</span>
            <span className="block text-[#FF5500]">BARBERSHOP</span>
          </h1>

          {/* Slogan Quote from Official Post */}
          <p className="text-lg sm:text-xl font-medium text-neutral-200 mb-6 italic tracking-wide border-l-2 border-[#FF5500] pl-4">
            "{BARBERSHOP_CONFIG.tagline}"
          </p>

          {/* Social Proof Line */}
          <div className="flex flex-wrap items-center gap-3 sm:gap-4 text-sm text-neutral-200 mb-8 pl-4 py-1">
            <div className="flex items-center gap-1.5 font-bold text-white">
              <Star className="w-4 h-4 fill-[#FF5500] text-[#FF5500]" />
              <span className="text-base tracking-wide tabular-nums">{BARBERSHOP_CONFIG.reputation.rating}</span>
            </div>
            <span className="text-neutral-500" aria-hidden="true">·</span>
            <span className="text-neutral-300">
              <strong className="text-white font-semibold tabular-nums">{BARBERSHOP_CONFIG.reputation.reviewCount}</strong> avaliações no Google
            </span>
            <span className="text-neutral-500 hidden sm:inline" aria-hidden="true">·</span>
            <div className="hidden sm:flex items-center gap-1 text-xs text-neutral-400">
              <MapPin className="w-3.5 h-3.5 text-[#FF5500]" />
              <span>Av. Pres. Vargas, 336 — Centro</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
            <button
              onClick={onOpenBooking}
              className="bg-[#FF5500] hover:bg-[#E04B00] text-black font-bold text-sm tracking-wider uppercase px-8 py-4 flex items-center justify-center gap-3 transition-colors cursor-pointer group shadow-lg shadow-[#FF5500]/15"
            >
              <span>AGENDAR HORÁRIO</span>
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </button>

            <a
              href={`https://wa.me/${BARBERSHOP_CONFIG.contact.whatsappRaw}`}
              target="_blank"
              rel="noopener noreferrer"
              className="border border-neutral-700 hover:border-[#FF5500] hover:text-[#FF5500] text-neutral-200 font-semibold text-xs tracking-widest uppercase px-6 py-4 flex items-center justify-center gap-2 transition-colors"
            >
              <Phone className="w-4 h-4 text-[#FF5500]" />
              <span>WHATSAPP {BARBERSHOP_CONFIG.contact.whatsapp}</span>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};
